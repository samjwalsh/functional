module Main where

import Ex1

main
  = putStrLn $ unlines
      [ "Running Exercise1"
      , "f1(11111111) = " ++ show (f1 11111111)
      ]
