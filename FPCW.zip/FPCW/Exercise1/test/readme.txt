The file 'Spec.hs' sets up a simple test framework.

It currently has four tests inside.

It can be run from within the 'Exercise1' or 'test' folders using the command:

> stack test

For your own use: 
feel free to add your own tests, 
and remove those already there. 

(This is not submitted as part of the exercise)