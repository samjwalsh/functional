( "Exercise" 
, [ ( "Ex1.hs",  1, "src" )
  , ( "Ex1.rns", 1, ""    )
  ]
)  
